# Creación del hola mundo (solo imprimiendo en pantalla)
print("Hola mundo")


# Creación del hola mundo (con una variable)
mensaje = "Hola mundo"
print(mensaje)
